﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


//using ThermalERP.Entities.Entities;

using ThermalERP.web.Models;

namespace ThermalERP.web.Services
{   
    public class LoginService : IDisposable
    {
        private readonly Thermal_PMSEntities _dbContext;

        public LoginService(Thermal_PMSEntities dbContext)
        {
            _dbContext = dbContext;
        }

        public bool checkLogin(LoginViewModel loginModel)
        {
            tbl_User user = _dbContext.tbl_User.Where(x => x.Email.ToLower().ToString() == loginModel.Email.ToLower().ToString() && x.Password == loginModel.Password).FirstOrDefault();
            var check = true;
            if (user != null)
	        {
		       check = true;    
	        }
            else
	        {
                check = false;
	        }
            return check;
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}