﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ActivityReportController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ActivityReport
        public ActionResult Index()
        {
            return View(db.Activity_Report.ToList());
        }

        // GET: ActivityReport/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            if (activity_Report == null)
            {
                return HttpNotFound();
            }
            return View(activity_Report);
        }

        // GET: ActivityReport/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Activity_Report, "Id", "Report_No");
            return PartialView("Partial_Create");

        }

        // POST: ActivityReport/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "id,Report_No,Date,Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned_StartDate,Planned_CompletionDate,Actual_StartDate,Actual_Completiondate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_Sl_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Activity_Report.Add(activity_Report);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", activity_Report.Report_No);
        //    return View(activity_Report);
        //}

        // GET: ActivityReport/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            if (activity_Report == null)
            {
                return HttpNotFound();
            }
            return View(activity_Report);
        }

        // POST: ActivityReport/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Report_No,Date,Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned_StartDate,Planned_CompletionDate,Actual_StartDate,Actual_Completiondate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_Sl_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Report).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Report);
        }

        // GET: ActivityReport/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            if (activity_Report == null)
            {
                return HttpNotFound();
            }
            return View(activity_Report);
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Report_No,Date,Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned_StartDate,Planned_CompletionDate,Actual_StartDate,Actual_Completiondate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_Sl_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Report.Add(activity_Report);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", activity_Report.Report_No);
            return PartialView(activity_Report);
        }


        // POST: ActivityReport/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Activity_Report activity_Report = db.Activity_Report.Find(id);
            db.Activity_Report.Remove(activity_Report);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
