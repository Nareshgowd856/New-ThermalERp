﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ThermalERP.web.Controllers
{
    public class ActivityMasterController : Controller
    {
        // GET: ActivityMaster
        public ActionResult LoadingDept()
        
            {
                List<SelectListItem> li = new List<SelectListItem>();
                li.Add(new SelectListItem { Text = "Select", Value = "0" });
                li.Add(new SelectListItem { Text = "CMD", Value = "1" });
                li.Add(new SelectListItem { Text = "ENGINEERING", Value = "2" });
                li.Add(new SelectListItem { Text = "PPD", Value = "3" });
                li.Add(new SelectListItem { Text = "PROCUREMENT", Value = "4" });
                li.Add(new SelectListItem { Text = "PRODUCTION", Value = "5" });
                li.Add(new SelectListItem { Text = "STORES", Value = "6" });
                ViewData["Departments"] = li;
                return View();
            }

        public JsonResult GetDept(string id)
        {
            List<SelectListItem> Activity = new List<SelectListItem>();
            switch (id)
            {
                case "1":
                    Activity.Add(new SelectListItem { Text = "Select", Value = "0" });
                    Activity.Add(new SelectListItem { Text = "CHECK LIST", Value = "1" });
                    Activity.Add(new SelectListItem { Text = "PO Acceptance", Value = "2" });
                    Activity.Add(new SelectListItem { Text = "WORN", Value = "3" });
                    Activity.Add(new SelectListItem { Text = "Project Mgr. Nomination Letter", Value = "4" });
                    Activity.Add(new SelectListItem { Text = "Budgets", Value = "5" });
                    Activity.Add(new SelectListItem { Text = "Internal KOM", Value = "6" });
                    Activity.Add(new SelectListItem { Text = "External KOM", Value = "7" });
                    Activity.Add(new SelectListItem { Text = "L3 Sch.", Value = "8" });
                    Activity.Add(new SelectListItem { Text = "BBU	", Value = "9" });
                    Activity.Add(new SelectListItem { Text = "Drawings sub/apprl", Value = "10" });
                    Activity.Add(new SelectListItem { Text = "VDRL", Value = "11" });
                    Activity.Add(new SelectListItem { Text = "Key Raw mtrl status", Value = "12" });
                    Activity.Add(new SelectListItem { Text = "QAP	", Value = "13" });
                    Activity.Add(new SelectListItem { Text = "ABG	", Value = "14" });
                    Activity.Add(new SelectListItem { Text = "PBG	", Value = "15" });
                    Activity.Add(new SelectListItem { Text = "Advance	", Value = "16" });
                    Activity.Add(new SelectListItem { Text = "Milestone	", Value = "17" });
                    Activity.Add(new SelectListItem { Text = "Progress Report	", Value = "18" });
                    Activity.Add(new SelectListItem { Text = "Despatch Clearance - Int", Value = "19" });
                    Activity.Add(new SelectListItem { Text = "Despatch Clearance - Client	", Value = "20" });
                    Activity.Add(new SelectListItem { Text = "Comm.Invoices", Value = "21" });
                    Activity.Add(new SelectListItem { Text = "Retention	", Value = "22" });
                    Activity.Add(new SelectListItem { Text = "Road Permits	", Value = "23" });
                    Activity.Add(new SelectListItem { Text = "Final Documentation	", Value = "24" });
                    Activity.Add(new SelectListItem { Text = "Erection Billing", Value = "25" });
                    Activity.Add(new SelectListItem { Text = "TDS Certificate	", Value = "26" });
                    Activity.Add(new SelectListItem { Text = "PG test certificate	", Value = "27" });
                    Activity.Add(new SelectListItem { Text = "Contract Closure Report	", Value = "28" });
                   
                    break;
                case "CMD":
                    break;
                
            }
            return Json(new SelectList(Activity, "Value", "Text"));
        }
        public JsonResult GetLink(string id)
        {
            List<SelectListItem> Links = new List<SelectListItem>();
            switch (id)
            {
                case "20":
                    Links.Add(new SelectListItem { Text = "Select", Value = "0" });
                    Links.Add(new SelectListItem { Text = "Attachment 1", Value = "1" });
                    Links.Add(new SelectListItem { Text = "Attachment 2", Value = "2" });
                    Links.Add(new SelectListItem { Text = "Attachment 3", Value = "3" });
                    Links.Add(new SelectListItem { Text = "Attachment 4", Value = "4" });
                    Links.Add(new SelectListItem { Text = "Attachment 5", Value = "5" });
                    Links.Add(new SelectListItem { Text = "Attachment 6", Value = "6" });
                    break;
            }

            return Json(new SelectList(Links, "Value", "Text"));
        }

    }
}