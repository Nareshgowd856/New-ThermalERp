﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ProjectGroupController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ProjectGroup
        public ActionResult Index()
        {
            return View(db.APG_Master.ToList());
        }

        // GET: ProjectGroup/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            APG_Master aPG_Master = db.APG_Master.Find(id);
            if (aPG_Master == null)
            {
                return HttpNotFound();
            }
            return View(aPG_Master);
        }

        // GET: ProjectGroup/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.APG_Master, "Id" , "APG NO");
            return PartialView("Partial_Create");
        }

        
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.APG_Master.Add(aPG_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
        //    return View(aPG_Master);
        //}

        // GET: ProjectGroup/Edit/5
        public ActionResult Edit(int? id)
        
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            APG_Master aPG_Master = db.APG_Master.Find(id);
            if (aPG_Master == null)
            {
                return HttpNotFound();
            }
            return View(aPG_Master);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        //public ActionResult Edit(APG_Master project)
        //{



        //        try
        //        {
        //            if (project.id == 0)
        //            {
        //                project.Created_By = Convert.ToString(Session["UserId"].ToString());
        //                project.Created_On = DateTime.Now;
        //                project.Created_By = Session["UserName"].ToString();
        //                db.APG_Master.Add(project);
        //                db.SaveChanges();
        //                return Json(new { success = true, message = "saved successfully" }, JsonRequestBehavior.AllowGet);
        //            }
        //            else
        //                {
        //                project.Modified_By = Convert.ToString(Session["UserId"]);
        //                project.Modified_On = DateTime.Now;
        //                project.Created_By = Session["Username"].ToString();
        //                db.Entry(project).State = System.Data.Entity.EntityState.Modified;
        //                db.SaveChanges();
        //                return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            throw ex;
        //        }
        //           }
        public ActionResult Edit([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(aPG_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
            return View(aPG_Master);
        }

        // GET: ProjectGroup/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            APG_Master aPG_Master = db.APG_Master.Find(id);
            if (aPG_Master == null)
            {
                return HttpNotFound();
            }
            return View(aPG_Master);
        }

        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
        {
            if (ModelState.IsValid)
            {
                db.APG_Master.Add(aPG_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
            return PartialView(aPG_Master);
        }


        //public ActionResult Partial_Edit()
        //{
        //    return PartialView();
        //}

        // POST: ProjectGroup/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {


            //APG_Master project = db.APG_Master.Where(x => x.id == id).FirstOrDefault<APG_Master>();
            //db.APG_Master.Remove(project);
            //db.SaveChanges();
            //return Json(new { success = true, message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);

            APG_Master aPG_Master = db.APG_Master.Find(id);
            db.APG_Master.Remove(aPG_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
