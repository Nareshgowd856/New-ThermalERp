﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ActivityController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: Activity
        public ActionResult Index()
        {
            return View(db.Activity_Master.ToList());
        }

        // GET: Activity/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // GET: Activity/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Activity_Master, "Id", "Activity_Code");
            return PartialView("Partial_Create");
        }

        // POST: Activity/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id")] Activity_Master activity_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Activity_Master.Add(activity_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Activity_Master, "Id", "Activity_Code", activity_Master.Activity_Code);
        //    return View(activity_Master);
        //}

        // GET: Activity/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // POST: Activity/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Master);
        }

        // GET: Activity/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }


        public ActionResult Partial_Create()
        {
            return PartialView();
        }
       

        [HttpPost]
        [ValidateAntiForgeryToken]
       public ActionResult Partial_Create([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Master.Add(activity_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Activity_Master, "Id", "Activity_Code", activity_Master.Activity_Code);
            return PartialView(activity_Master);
        }


        // POST: Activity/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            db.Activity_Master.Remove(activity_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
