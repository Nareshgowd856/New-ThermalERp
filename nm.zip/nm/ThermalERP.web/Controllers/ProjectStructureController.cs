﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ProjectStructureController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ProjectStructure
        public ActionResult Index()
        {
            return View(db.Project_Structure_Main.ToList());
        }

        // GET: ProjectStructure/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
            if (project_Structure_Main == null)
            {
                return HttpNotFound();
            }
            return View(project_Structure_Main);
        }

        // GET: ProjectStructure/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code");
            return PartialView("Partial_Create");
        }

        // POST: ProjectStructure/Create
        
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Project_Structure_Main.Add(project_Structure_Main);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code", project_Structure_Main.Project_Code);
        //    return View(project_Structure_Main);
        //}

        // GET: ProjectStructure/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
            if (project_Structure_Main == null)
            {
                return HttpNotFound();
            }
            return View(project_Structure_Main);
        }

        // POST: ProjectStructure/Edit/5
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
        {
            if (ModelState.IsValid)
            {
                db.Entry(project_Structure_Main).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(project_Structure_Main);
        }

        // GET: ProjectStructure/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
            if (project_Structure_Main == null)
            {
                return HttpNotFound();
            }
            return View(project_Structure_Main);
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Project_Code,Maker_No,Maker_Name,APG_No,APG_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,Full_Project_Code")] Project_Structure_Main project_Structure_Main)
        {
            if (ModelState.IsValid)
            {
                db.Project_Structure_Main.Add(project_Structure_Main);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Project_Structure_Main, "Id", "Project_Code", project_Structure_Main.Project_Code);
            return PartialView(project_Structure_Main);
        }
        // POST: ProjectStructure/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Project_Structure_Main project_Structure_Main = db.Project_Structure_Main.Find(id);
            db.Project_Structure_Main.Remove(project_Structure_Main);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
