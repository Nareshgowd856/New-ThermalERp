
namespace ThermalERP.web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class Part_List_Item
    {
        public int id { get; set; }
        [Display(Name = "Project Code")]
        public string Project_Code { get; set; }
        [Display(Name = "Maker No")]
        public string Maker_No { get; set; }
        [Display(Name = "APG No")]
        public string Apg_No { get; set; }
        [Display(Name = "APG Name")]
        public string Apg_Name { get; set; }
        [Display(Name = "PartList No")]
        public string Partlist_No { get; set; }
        [Display(Name = "part Group")]
        public string Part_Group { get; set; }
        [Display(Name = "Part SI No")]
        public string Part_Sl_No { get; set; }
        [Display(Name = "Part Name")]
        public string Part_Name { get; set; }
        [Display(Name = "Part Description")]
        public string Part_Desription { get; set; }
        [Display(Name = "Part Variant")]
        public string Part_variant { get; set; }
        [Display(Name = "Part UOM")]
        public string Part_UOM { get; set; }
        [Display(Name = "Part Spec Id")]
        public string Part_Spec_Id { get; set; }
        [Display(Name = "Part Rm Type")]
        public string Part_Rm_Type { get; set; }
        [Display(Name = "Part Rm WThick")]
        public Nullable<decimal> Part_Rm_WThick { get; set; }
        [Display(Name = "Part_Rm_Density")]
        public Nullable<decimal> Part_Rm_Density { get; set; }
        [Display(Name = " Part Mtc Cert")]
        public string Part_Mtc_Cert { get; set; }
        [Display(Name = "Part IBR Cert")]
        public string Part_IBR_Cert { get; set; }
        [Display(Name = "Part EN Cert")]
        public string Part_EN_Cert { get; set; }
        [Display(Name = "Part RM Code")]
        public string Part_RM_Code { get; set; }
        [Display(Name = "Part Dia")]
        public Nullable<decimal> Part_Dia { get; set; }
        [Display(Name = "Part WT")]
        public Nullable<decimal> Part_Wt { get; set; }
        [Display(Name = "Part Length")]
        public Nullable<decimal> Part_Length { get; set; }
        [Display(Name = " Part W2")]
        public Nullable<decimal> Part_W2 { get; set; }
        [Display(Name = " Part Fg Wt")]
        public Nullable<decimal> Part_Fg_wt { get; set; }
        [Display(Name = " Part Rm Wt")]
        public Nullable<decimal> Part_Rm_Wt { get; set; }
        [Display(Name = " Part D Wt")]
        public Nullable<decimal> Part_D_Wt { get; set; }
        [Display(Name = " Part Engg Code")]
        public string Part_Engg_Code { get; set; }
        public string CompId { get; set; }
        [Display(Name = "Version No")]
        public string Version_No { get; set; }
       [Display(Name = "Version Date")] 
        public Nullable<System.DateTime> Version_Date { get; set; }
        [Display(Name = "Version Change")]
        public string Version_Change { get; set; }
        public string Created { get; set; }
        [Display(Name = "Created By ")]
        public Nullable<System.DateTime> Creted_By { get; set; }
        [Display(Name = "Modified")]
        public string Modified { get; set; }
        [Display(Name = "Modified By")]
        public Nullable<System.DateTime> Modified_By { get; set; }
        public Nullable<decimal> Qty { get; set; }
        public Nullable<decimal> OD { get; set; }
        [Display(Name = "Part Equipment Name")]
        public string Part_Equipment_Name { get; set; }
        public string Status { get; set; }
        [Display(Name = "Drawing No")]
        public string Drawing_NO { get; set; }
        [Display(Name = "PTS No")]
        public string PTS_NO { get; set; }
        [Display(Name = "Main Drawing No")]
        public string Main_Drwaing_No { get; set; }
        [Display(Name = "Activity Part No" )]
        public string Activity_Part_No { get; set; }
    }
}
