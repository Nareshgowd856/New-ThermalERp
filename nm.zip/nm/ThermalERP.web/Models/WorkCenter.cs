

namespace ThermalERP.web.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public partial class WorkCenter
    {
        public int id { get; set; }
        [Display(Name = "Work Center Id")]
        public string Work_Center_id { get; set; }
        [Display(Name = "Work Center")]
        public string Work_Center { get; set; }
        public string CompID { get; set; }
        [Display(Name = "Created By")]
        public string Created_By { get; set; }
        [Display(Name = "Created On")]
        public Nullable<System.DateTime> Created_On { get; set; }
        [Display(Name = "Modified By")]
        public string Modified_By { get; set; }
        [Display(Name = "Modified On")]
        public Nullable<System.DateTime> modified_On { get; set; }
    }
}
